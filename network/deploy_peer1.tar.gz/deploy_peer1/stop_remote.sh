#!/bin/bash
set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=/dev/null
source "$SCRIPT_DIR/node.env"

if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
    RUNTIME="docker"
elif command -v podman >/dev/null 2>&1 && podman info >/dev/null 2>&1; then
    RUNTIME="podman"
else
    echo "Neither docker nor podman is reachable."
    exit 1
fi

"$RUNTIME" rm -f "$PEER_NAME" cli 2>/dev/null || true
echo "Stopped $PEER_NAME"
