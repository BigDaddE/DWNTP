1. Copy this folder to the remote host.
2. Start the peer and local cli on the remote host:
   ./start_remote.sh
3. On the coordinator host, onboard the peer:
   ./network/onboard_remote_peer.sh 1 83.249.250.116
4. On the remote host, dwntp-client can now use the local cli container.
