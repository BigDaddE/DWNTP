#!/bin/bash
set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=/dev/null
source "$SCRIPT_DIR/node.env"

detect_runtime() {
    if [ -n "${CONTAINER_RUNTIME:-}" ]; then
        echo "$CONTAINER_RUNTIME"
        return 0
    fi

    if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
        echo "docker"
        return 0
    fi

    if command -v podman >/dev/null 2>&1 && podman info >/dev/null 2>&1; then
        echo "podman"
        return 0
    fi

    if command -v "$REMOTE_RUNTIME" >/dev/null 2>&1; then
        echo "$REMOTE_RUNTIME"
        return 0
    fi

    echo "Neither docker nor podman is reachable on the remote host."
    exit 1
}

RUNTIME=$(detect_runtime)
VOLUME_SUFFIX=""
if [ "$RUNTIME" = "podman" ]; then
    VOLUME_SUFFIX=":z"
fi

"$RUNTIME" rm -f "$PEER_NAME" 2>/dev/null || true
"$RUNTIME" rm -f cli 2>/dev/null || true
"$RUNTIME" network inspect dwntp-remote >/dev/null 2>&1 || "$RUNTIME" network create dwntp-remote

"$RUNTIME" run -d --restart unless-stopped --name "$PEER_NAME" --network dwntp-remote \
  --add-host "orderer.dwntp.com:${MAIN_PUBLIC_HOST}" \
  --add-host "peer0.org1.dwntp.com:${MAIN_PUBLIC_HOST}" \
  --add-host "dwntp-chaincode:${MAIN_PUBLIC_HOST}" \
  -p "${PEER_PORT}:7051" \
  -p "${CHAINCODE_PORT}:7052" \
  -p "${OPERATIONS_PORT}:9443" \
  -e FABRIC_LOGGING_SPEC=INFO \
  -e CORE_OPERATIONS_LISTENADDRESS=0.0.0.0:9443 \
  -e CORE_METRICS_PROVIDER=prometheus \
  -e CORE_PEER_ID="$PEER_NAME" \
  -e CORE_PEER_ADDRESS="${PEER_NAME}:7051" \
  -e CORE_PEER_LISTENADDRESS=0.0.0.0:7051 \
  -e CORE_PEER_CHAINCODEADDRESS="${PEER_NAME}:7052" \
  -e CORE_PEER_CHAINCODELISTENADDRESS=0.0.0.0:7052 \
  -e CORE_PEER_GOSSIP_BOOTSTRAP="peer0.org1.dwntp.com:7051" \
  -e CORE_PEER_GOSSIP_EXTERNALENDPOINT="${PEER_NAME}:${PEER_PORT}" \
  -e CORE_PEER_LOCALMSPID=Org1MSP \
  -e CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/fabric/msp \
  -e CORE_PEER_TLS_ENABLED=true \
  -e CORE_PEER_TLS_CERT_FILE=/etc/hyperledger/fabric/tls/server.crt \
  -e CORE_PEER_TLS_KEY_FILE=/etc/hyperledger/fabric/tls/server.key \
  -e CORE_PEER_TLS_ROOTCERT_FILE=/etc/hyperledger/fabric/tls/ca.crt \
  -e CORE_VM_ENDPOINT= \
  -v "$SCRIPT_DIR/crypto-config/peerOrganizations/org1.dwntp.com/peers/${PEER_NAME}/msp:/etc/hyperledger/fabric/msp${VOLUME_SUFFIX}" \
  -v "$SCRIPT_DIR/crypto-config/peerOrganizations/org1.dwntp.com/peers/${PEER_NAME}/tls:/etc/hyperledger/fabric/tls${VOLUME_SUFFIX}" \
  docker.io/hyperledger/fabric-peer:2.5 peer node start

echo "Remote peer started:"
echo "  $PEER_NAME"
echo "  mapped public endpoint: ${PEER_PUBLIC_HOST}:${PEER_PORT}"

"$RUNTIME" run -d -it --restart unless-stopped --name cli --network dwntp-remote \
  --add-host "orderer.dwntp.com:${MAIN_PUBLIC_HOST}" \
  --add-host "peer0.org1.dwntp.com:${MAIN_PUBLIC_HOST}" \
  --add-host "dwntp-chaincode:${MAIN_PUBLIC_HOST}" \
  -e GOPATH=/opt/gopath \
  -e FABRIC_LOGGING_SPEC=INFO \
  -e CORE_PEER_ID=cli \
  -e CORE_PEER_ADDRESS="${PEER_NAME}:7051" \
  -e CORE_PEER_LOCALMSPID=Org1MSP \
  -e CORE_PEER_TLS_ENABLED=true \
  -e CORE_PEER_TLS_CERT_FILE="/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.dwntp.com/peers/${PEER_NAME}/tls/server.crt" \
  -e CORE_PEER_TLS_KEY_FILE="/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.dwntp.com/peers/${PEER_NAME}/tls/server.key" \
  -e CORE_PEER_TLS_ROOTCERT_FILE="/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.dwntp.com/peers/${PEER_NAME}/tls/ca.crt" \
  -e CORE_PEER_MSPCONFIGPATH="/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.dwntp.com/users/Admin@org1.dwntp.com/msp" \
  -e ORDERER_CA="/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/dwntp.com/orderers/orderer.dwntp.com/tls/ca.crt" \
  -v "$SCRIPT_DIR/crypto-config:/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto${VOLUME_SUFFIX}" \
  docker.io/hyperledger/fabric-tools:2.5 /bin/bash

echo "Remote CLI started:"
echo "  cli"
